### List of custom/optional Sound Effect *dat* files which can be used in zc210 core

You can select and use these from the Core Options menu. You need to restart RetroArch to apply the changes.

- BSZelda.dat: Sound effects from BS Zelda game.
- LinksAwakening.dat: Sound effects from Legend of Zelda Link's Awakening game.
- LinkTothePast.dat: Sound effects from Legend of Zelda A Link the Past game.
- Metroid.dat: Sound effects from Metroid NES game.
- Elise.dat: Sound effects from Search for Elise quest.
- Castle.dat: Sound effects from Castle Haunt quest.
- SwangSong.dat: Sound effects from Swang Song quest.
- Tortuga.dat: Sound effects from Link to Tortuga quest.
- Custom.dat: Slot you can use to add another SFX dat file. Just rename it to this name and drop into the system/zc120/sfx folder.

